package ASM.entity;

import java.io.Serializable;
import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "KhachHang")
public class Product implements Serializable {
	@Id
	@NotBlank(message="{NotBlank.kh.taikhoan}")
	String taikhoan;
	@NotBlank(message="{NotBlank.kh.matkhau}")
	String matkhau;
	@NotNull(message="{NotNull.kh.hoten}")
	String hoten;
	@NotNull(message="{NotNull.kh.gioitinh}")
	boolean gioitinh;
	boolean chucvu;
	@NotBlank(message= "{NotBlank.kh.email}")
	@Email(message = "{Email.kh.email}")
	String email;
	@NotNull(message="{NotNull.kh.sdt}")
	String sdt;
	Date ngaysinh;
}
