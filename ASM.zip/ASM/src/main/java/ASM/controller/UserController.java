package ASM.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ASM.dao.ProductDAO;
import ASM.entity.Product;
import ASM.model.CookieUtils;
import ASM.model.MailInfo;
import ASM.service.MailerService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class UserController {
	@Autowired
	ProductDAO khdao;
	@Autowired
	MailerService mailer;
	@Autowired
	HttpServletRequest request;
	@Autowired
	HttpServletResponse response;
	
	@GetMapping("/dangnhap")
	public String getCreate() {
		String username = CookieUtils.get("username", request);
		String password = CookieUtils.get("password", request);
		request.setAttribute("users", username);
		request.setAttribute("pass", password);
		return "dangnhap";
	}
	
	@PostMapping("/dangnhap")
	public String postCreate(Model model, @RequestParam("taikhoan") String taikhoan,
			@RequestParam("matkhau") String matkhau) {
		String username = request.getParameter("taikhoan");
		String password = request.getParameter("matkhau");
		String remember = request.getParameter("remember");
		try {
			Product kh = khdao.findById(taikhoan).get();
			if(kh == null || !kh.getMatkhau().equals(matkhau)) {
				model.addAttribute("message","Tài khoảng hoặc mật khẩu không đúng");
			}else {
				int hours = (remember == null) ? 0 : 30*24; // 0 = xóa
				CookieUtils.add("username", username, hours, response);
				CookieUtils.add("password", password, hours, response);
				model.addAttribute("message", "Login succeed");
				return "trangchu";
			}
		} catch (Exception e) {
			model.addAttribute("message","Tài khoảng hoặc mật khẩu không đúng");
		}
		return "dangnhap";
	}
	@RequestMapping("/dangky")
	public String dangKy(Model model) {
		Product kh = new Product();
		model.addAttribute("kh",kh);
		return "dangky";
	}
	@RequestMapping("/trangchu")
	public String trangChu() {
		return "trangchu";
	}
	@RequestMapping("/quenmatkhau")
	public String quenMatKhau(Model model) {
				MailInfo mail = new MailInfo();
				model.addAttribute("mail",mail);
		return "quenmatkhau";
	}
	
	@RequestMapping("/khachhang/dangky")
	public String dangky(Model model, @Validated @ModelAttribute("kh") Product kh, BindingResult result) {
		if(result.hasErrors()) {
			model.addAttribute("message","Vui lòng nhập đủ thông tin");
		}else {
			model.addAttribute("message","Đăng ký thành công !");
			khdao.save(kh);
			try {
			    Thread.sleep(5000); // Ngủ trong 5 giây
			    //return "redirect:/dangnhap";
			} catch (InterruptedException e) {
			    e.printStackTrace();
			}
		}
		return "dangky";
	}
	
	@ModelAttribute("gioitinhs")
	public Map<Boolean, String> getGenders(){
	Map<Boolean, String> map = new HashMap<>();
	map.put(true, "Nam");
	map.put(false, "Nữ");
	return map;
	}
	@RequestMapping("/khachhang/quenmatkhau")
	public String quenmatkhau(Model model, @RequestParam String to,@RequestParam String taikhoan ) {
		Random random = new Random();
		try {
			int randomNumber = random.nextInt(900000) + 100000;
			Product kh = khdao.findById(taikhoan).get();
			String subject = "Quản lý kho";
			String body = String.valueOf(randomNumber);
			if(!kh.getEmail().equals(to)) {
				System.out.println(to);
				System.out.println(kh.getEmail());
				model.addAttribute("message","Tài khoản và email không phù hợp !");
			}else {
				model.addAttribute("message","Vui lòng vào email để nhận mật khẩu mới !");
				kh.setMatkhau(body);
				khdao.save(kh);
				MailInfo mail = new MailInfo();
				mail.setTo(to);
				mail.setSubject(subject);
				mail.setBody("Mật khẩu mới: " +body);
				mailer.queue(mail);
				try {
					mailer.send(mail);
				}catch(Exception e) {
					System.out.println(e.getMessage());
				}
				//return "redirect:/dangnhap";
			}
		} catch (Exception e) {
			// TODO: handle exception
			model.addAttribute("message","Tài khoản và email không phù hợp!");
		}
		return "/quenmatkhau";
	}
	@RequestMapping("/quayve")
	public String quayve() {
		return "redirect:/dangnhap";
	}
}
