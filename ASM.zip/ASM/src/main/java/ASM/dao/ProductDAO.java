package ASM.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import ASM.entity.Product;

public interface ProductDAO extends JpaRepository<Product, String> {
	
}
